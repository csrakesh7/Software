Place PHPMailer files (PHPMailer.php, SMTP.php, Exception.php) here.
Download from https://github.com/PHPMailer/PHPMailer